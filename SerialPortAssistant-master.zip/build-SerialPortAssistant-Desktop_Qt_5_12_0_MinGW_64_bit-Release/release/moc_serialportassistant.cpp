/****************************************************************************
** Meta object code from reading C++ file 'serialportassistant.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../SerialPortAssistant-master/serialportassistant.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'serialportassistant.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_SerialPortAssistant_t {
    QByteArrayData data[45];
    char stringdata0[982];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_SerialPortAssistant_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_SerialPortAssistant_t qt_meta_stringdata_SerialPortAssistant = {
    {
QT_MOC_LITERAL(0, 0, 19), // "SerialPortAssistant"
QT_MOC_LITERAL(1, 20, 16), // "switchSerialPort"
QT_MOC_LITERAL(2, 37, 0), // ""
QT_MOC_LITERAL(3, 38, 7), // "receive"
QT_MOC_LITERAL(4, 46, 4), // "send"
QT_MOC_LITERAL(5, 51, 8), // "transmit"
QT_MOC_LITERAL(6, 60, 14), // "transmitString"
QT_MOC_LITERAL(7, 75, 19), // "transmitHexadecimal"
QT_MOC_LITERAL(8, 95, 18), // "transmitCircularly"
QT_MOC_LITERAL(9, 114, 12), // "transmitFile"
QT_MOC_LITERAL(10, 127, 8), // "openFile"
QT_MOC_LITERAL(11, 136, 6), // "saveAs"
QT_MOC_LITERAL(12, 143, 5), // "clear"
QT_MOC_LITERAL(13, 149, 30), // "on_Get_Active_Electric_clicked"
QT_MOC_LITERAL(14, 180, 26), // "on_power_frequency_clicked"
QT_MOC_LITERAL(15, 207, 20), // "on_sendclear_clicked"
QT_MOC_LITERAL(16, 228, 21), // "on_A_Electric_clicked"
QT_MOC_LITERAL(17, 250, 21), // "on_B_Electric_clicked"
QT_MOC_LITERAL(18, 272, 21), // "on_C_Electric_clicked"
QT_MOC_LITERAL(19, 294, 25), // "on_A_active_power_clicked"
QT_MOC_LITERAL(20, 320, 25), // "on_B_active_power_clicked"
QT_MOC_LITERAL(21, 346, 25), // "on_C_active_power_clicked"
QT_MOC_LITERAL(22, 372, 27), // "on_A_Reactive_power_clicked"
QT_MOC_LITERAL(23, 400, 27), // "on_B_Reactive_power_clicked"
QT_MOC_LITERAL(24, 428, 27), // "on_C_Reactive_power_clicked"
QT_MOC_LITERAL(25, 456, 27), // "on_A_Apparent_power_clicked"
QT_MOC_LITERAL(26, 484, 27), // "on_B_Apparent_power_clicked"
QT_MOC_LITERAL(27, 512, 27), // "on_C_Apparent_power_clicked"
QT_MOC_LITERAL(28, 540, 25), // "on_A_factor_power_clicked"
QT_MOC_LITERAL(29, 566, 25), // "on_B_factor_power_clicked"
QT_MOC_LITERAL(30, 592, 25), // "on_C_factor_power_clicked"
QT_MOC_LITERAL(31, 618, 29), // "on_Total_active_power_clicked"
QT_MOC_LITERAL(32, 648, 31), // "on_Total_Reactive_power_clicked"
QT_MOC_LITERAL(33, 680, 31), // "on_Total_Apparent_power_clicked"
QT_MOC_LITERAL(34, 712, 30), // "on_Total_power_factor__clicked"
QT_MOC_LITERAL(35, 743, 20), // "on_A_Voltage_clicked"
QT_MOC_LITERAL(36, 764, 20), // "on_B_Voltage_clicked"
QT_MOC_LITERAL(37, 785, 20), // "on_C_Voltage_clicked"
QT_MOC_LITERAL(38, 806, 21), // "on_N_Electric_clicked"
QT_MOC_LITERAL(39, 828, 24), // "on_A_total_power_clicked"
QT_MOC_LITERAL(40, 853, 24), // "on_B_total_power_clicked"
QT_MOC_LITERAL(41, 878, 24), // "on_C_total_power_clicked"
QT_MOC_LITERAL(42, 903, 18), // "on_testall_clicked"
QT_MOC_LITERAL(43, 922, 27), // "on_checkBox_28_stateChanged"
QT_MOC_LITERAL(44, 950, 31) // "on_Temperature_humidity_clicked"

    },
    "SerialPortAssistant\0switchSerialPort\0"
    "\0receive\0send\0transmit\0transmitString\0"
    "transmitHexadecimal\0transmitCircularly\0"
    "transmitFile\0openFile\0saveAs\0clear\0"
    "on_Get_Active_Electric_clicked\0"
    "on_power_frequency_clicked\0"
    "on_sendclear_clicked\0on_A_Electric_clicked\0"
    "on_B_Electric_clicked\0on_C_Electric_clicked\0"
    "on_A_active_power_clicked\0"
    "on_B_active_power_clicked\0"
    "on_C_active_power_clicked\0"
    "on_A_Reactive_power_clicked\0"
    "on_B_Reactive_power_clicked\0"
    "on_C_Reactive_power_clicked\0"
    "on_A_Apparent_power_clicked\0"
    "on_B_Apparent_power_clicked\0"
    "on_C_Apparent_power_clicked\0"
    "on_A_factor_power_clicked\0"
    "on_B_factor_power_clicked\0"
    "on_C_factor_power_clicked\0"
    "on_Total_active_power_clicked\0"
    "on_Total_Reactive_power_clicked\0"
    "on_Total_Apparent_power_clicked\0"
    "on_Total_power_factor__clicked\0"
    "on_A_Voltage_clicked\0on_B_Voltage_clicked\0"
    "on_C_Voltage_clicked\0on_N_Electric_clicked\0"
    "on_A_total_power_clicked\0"
    "on_B_total_power_clicked\0"
    "on_C_total_power_clicked\0on_testall_clicked\0"
    "on_checkBox_28_stateChanged\0"
    "on_Temperature_humidity_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_SerialPortAssistant[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      43,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  229,    2, 0x0a /* Public */,
       3,    0,  230,    2, 0x0a /* Public */,
       4,    0,  231,    2, 0x0a /* Public */,
       5,    0,  232,    2, 0x0a /* Public */,
       6,    0,  233,    2, 0x0a /* Public */,
       7,    0,  234,    2, 0x0a /* Public */,
       8,    0,  235,    2, 0x0a /* Public */,
       9,    0,  236,    2, 0x0a /* Public */,
      10,    0,  237,    2, 0x0a /* Public */,
      11,    0,  238,    2, 0x0a /* Public */,
      12,    0,  239,    2, 0x0a /* Public */,
      13,    0,  240,    2, 0x0a /* Public */,
      14,    0,  241,    2, 0x0a /* Public */,
      15,    0,  242,    2, 0x0a /* Public */,
      16,    0,  243,    2, 0x08 /* Private */,
      17,    0,  244,    2, 0x08 /* Private */,
      18,    0,  245,    2, 0x08 /* Private */,
      19,    0,  246,    2, 0x08 /* Private */,
      20,    0,  247,    2, 0x08 /* Private */,
      21,    0,  248,    2, 0x08 /* Private */,
      22,    0,  249,    2, 0x08 /* Private */,
      23,    0,  250,    2, 0x08 /* Private */,
      24,    0,  251,    2, 0x08 /* Private */,
      25,    0,  252,    2, 0x08 /* Private */,
      26,    0,  253,    2, 0x08 /* Private */,
      27,    0,  254,    2, 0x08 /* Private */,
      28,    0,  255,    2, 0x08 /* Private */,
      29,    0,  256,    2, 0x08 /* Private */,
      30,    0,  257,    2, 0x08 /* Private */,
      31,    0,  258,    2, 0x08 /* Private */,
      32,    0,  259,    2, 0x08 /* Private */,
      33,    0,  260,    2, 0x08 /* Private */,
      34,    0,  261,    2, 0x08 /* Private */,
      35,    0,  262,    2, 0x08 /* Private */,
      36,    0,  263,    2, 0x08 /* Private */,
      37,    0,  264,    2, 0x08 /* Private */,
      38,    0,  265,    2, 0x08 /* Private */,
      39,    0,  266,    2, 0x08 /* Private */,
      40,    0,  267,    2, 0x08 /* Private */,
      41,    0,  268,    2, 0x08 /* Private */,
      42,    0,  269,    2, 0x08 /* Private */,
      43,    0,  270,    2, 0x08 /* Private */,
      44,    0,  271,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void SerialPortAssistant::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        SerialPortAssistant *_t = static_cast<SerialPortAssistant *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->switchSerialPort(); break;
        case 1: _t->receive(); break;
        case 2: _t->send(); break;
        case 3: _t->transmit(); break;
        case 4: _t->transmitString(); break;
        case 5: _t->transmitHexadecimal(); break;
        case 6: _t->transmitCircularly(); break;
        case 7: _t->transmitFile(); break;
        case 8: _t->openFile(); break;
        case 9: _t->saveAs(); break;
        case 10: _t->clear(); break;
        case 11: _t->on_Get_Active_Electric_clicked(); break;
        case 12: _t->on_power_frequency_clicked(); break;
        case 13: _t->on_sendclear_clicked(); break;
        case 14: _t->on_A_Electric_clicked(); break;
        case 15: _t->on_B_Electric_clicked(); break;
        case 16: _t->on_C_Electric_clicked(); break;
        case 17: _t->on_A_active_power_clicked(); break;
        case 18: _t->on_B_active_power_clicked(); break;
        case 19: _t->on_C_active_power_clicked(); break;
        case 20: _t->on_A_Reactive_power_clicked(); break;
        case 21: _t->on_B_Reactive_power_clicked(); break;
        case 22: _t->on_C_Reactive_power_clicked(); break;
        case 23: _t->on_A_Apparent_power_clicked(); break;
        case 24: _t->on_B_Apparent_power_clicked(); break;
        case 25: _t->on_C_Apparent_power_clicked(); break;
        case 26: _t->on_A_factor_power_clicked(); break;
        case 27: _t->on_B_factor_power_clicked(); break;
        case 28: _t->on_C_factor_power_clicked(); break;
        case 29: _t->on_Total_active_power_clicked(); break;
        case 30: _t->on_Total_Reactive_power_clicked(); break;
        case 31: _t->on_Total_Apparent_power_clicked(); break;
        case 32: _t->on_Total_power_factor__clicked(); break;
        case 33: _t->on_A_Voltage_clicked(); break;
        case 34: _t->on_B_Voltage_clicked(); break;
        case 35: _t->on_C_Voltage_clicked(); break;
        case 36: _t->on_N_Electric_clicked(); break;
        case 37: _t->on_A_total_power_clicked(); break;
        case 38: _t->on_B_total_power_clicked(); break;
        case 39: _t->on_C_total_power_clicked(); break;
        case 40: _t->on_testall_clicked(); break;
        case 41: _t->on_checkBox_28_stateChanged(); break;
        case 42: _t->on_Temperature_humidity_clicked(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject SerialPortAssistant::staticMetaObject = { {
    &QMainWindow::staticMetaObject,
    qt_meta_stringdata_SerialPortAssistant.data,
    qt_meta_data_SerialPortAssistant,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *SerialPortAssistant::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *SerialPortAssistant::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_SerialPortAssistant.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int SerialPortAssistant::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 43)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 43;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 43)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 43;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
